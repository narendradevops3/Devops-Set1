package demo.training;

/*public class Demo {
	 
		  static{  
		  System.out.println("static block is invoked");  
		  System.exit(0);  
		  }  
		  public static void main(String args[])
		  {
			  
		  }
		}*/
/*class A{  // Restrictions for static method
	 int a=40;//non static  
	   
	 public static void main(String args[]){  
	  System.out.println(a);  
	 }  
	} */     