package com.datadotz.stringdemo;

public class Strinexample {
 public static void main(String args[]) {
 String s = "datadotz";

 s.concat("hai");
 System.out.println(s);

 }
 
}



































//public class Strinexample {
//	public static void main(String[] args) {
//		String str1 = "barfoo";
//		String str2 = "barfoo";
//
//		int compareResult = str1.compareTo(str2);
//
//		if (compareResult < 0) {
//			System.out.println(str1 + "is less than" + str2);
//		} else if (compareResult == 0) {
//			System.out.println(str1 + "is equal to" + str2);
//		} else {
//			System.out.println(str1 + "is greater than" + str2);
//		}
//	}

