package me.sudohippie.weather.service.rest;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.XML;

public class RESTClientTest {
	public static void main(String[] args) throws IOException, JSONException {
		String endpoint = "http://graphical.weather.gov/xml/sample_products/browser_interface/ndfdXMLclient.php";
		RESTClient client = new RESTClient(endpoint);

		Map<String, String> params = new LinkedHashMap<String, String>();
		params.put("listLatLon", "40.71,-74.01");
		params.put("startTime", "2004-01-01T00:00:00");
		params.put("endTime", "2017-09-12T00:00:00");
		params.put("compType", "Between");
		params.put("featureType", "Forecast_Gml2Point");
		params.put("propertyName", "maxt,mint,wx");

		String dataAsString = client.getDataAsString(params);
		org.json.JSONObject DatainJsonObject = XML.toJSONObject(dataAsString);
		//System.out.println(DatainJsonObject.toString());
		File file = new File("D:/s1.json");
		if (!file.exists()) {
			file.createNewFile();
			BufferedWriter bw = new BufferedWriter(new FileWriter(file));
			bw.write(DatainJsonObject.toString());
		}

		System.out.println("Done");
	}
}
