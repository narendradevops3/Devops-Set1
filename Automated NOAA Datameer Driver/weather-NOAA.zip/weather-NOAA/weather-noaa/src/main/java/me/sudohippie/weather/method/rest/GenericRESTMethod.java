package me.sudohippie.weather.method.rest;

/**
 * Raghav Sidhanti
 * 9/20/13
 */
public class GenericRESTMethod extends NOAARESTMethod {
}
